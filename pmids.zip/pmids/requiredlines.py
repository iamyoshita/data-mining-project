file1 = open('annotatedabstracts.txt', 'r')
Lines = file1.readlines()
 
count = 0
print("read")
# Strips the newline character
for line in Lines:
    print(line)
    break
    if("GENE" in line):
        continue
    count += 1
    break
